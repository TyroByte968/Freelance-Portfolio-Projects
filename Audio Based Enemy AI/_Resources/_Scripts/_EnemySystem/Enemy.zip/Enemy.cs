using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;

using System.Collections;
using System.Collections.Generic;

using DC.Scanner;
using Homebrew;



public enum EnemyState
{
    Patrolling,
    Alert,
    Chasing
};
public class Enemy : MonoBehaviour
{
    [Foldout("Enemy Settings",true)]
    public EnemyState enemyState;
    public NavMeshAgent Agent;
    public float MoveSpeed;
    public float AlertMoveSpeed;
    public float MaxDist = 10;
    public float MinDist = 5;
    public GameObject ChaseIndicator;
    public GameObject AlertIndicator;
   
    [Foldout("Scanner Settings",true)]
    public TargetScanner targetScanner;
    public Transform Player;

    [Foldout("Patrol Settings",true)]
    public List<Transform> PatrolWayPoints;
    public List<Transform> AlertWayPoints;
    [Space(5)]
    public int CurrentWaypointIndex;
    public bool RouteFinished;

    [Foldout("Chase Settings",true)]
    public UnityEvent EnterEvent;
    public UnityEvent ExitEvent;
    public bool EnemyWasAlert;

    [Foldout("Alert Settings",true)]
    public float AlertWayPointDistance;
    public float WallCheckDistance = 5f;
    public  LayerMask WallCheckLayerMask;
 
    [Foldout("Hearing Settings",true)]
    public float EnemyHearingRange;
    public LayerMask detectionLayer;
    [Space(5)]
    public float MinCheckSound;
    public float MaxCheckSound;
    [Space(5)]
    public bool WanderingWhenAlert;



    [Foldout("Debug Settings",true)]
    public Transform CurrentTarget;
    public Transform OldTarget;
    public GameObject HighestSoundObjectNoticed;
    public float HighestSoundNoticed;
    [Space(5)]
    public bool EnterEventPlayed;
    public bool ExitEventPlayed;

    void Start()
    {
        Agent.speed = MoveSpeed;
    }

    void Update()
    {
        ChaseIndicator.SetActive(enemyState == EnemyState.Chasing);
        AlertIndicator.SetActive(enemyState == EnemyState.Alert);

        switch (enemyState)
        {
            case EnemyState.Patrolling:
                PatrolBehavior();
                break;
            case EnemyState.Alert:
                AlertBehavior();
                break;
            case EnemyState.Chasing:
                ChaseBehavior();
                break;
        }
    }

   

    private void PatrolBehavior()
    {
        
            CurrentTarget = PatrolWayPoints[CurrentWaypointIndex].transform;
            OldTarget = CurrentTarget;
            Agent.SetDestination(CurrentTarget.transform.position);

      

            //Vector3,Distance is too trippy to figure out what's going on, I adjusted some values and it works somehow
            //Basically makes sure to go to the next waypoint if in minimum distance to the current target waypoint
            if (Vector3.Distance(transform.position, CurrentTarget.position) >= MinDist)
            {
                SetEnemyState(0);            
            }

            else if(Vector3.Distance(transform.position, CurrentTarget.position) <= MaxDist)
            {
                //Debug.Log(CurrentWaypointIndex);

                if(CurrentWaypointIndex >= 0&&CurrentWaypointIndex != PatrolWayPoints.Count-1)
                {
                    CurrentWaypointIndex += 1;
                    RouteFinished = false;
                }
                else if(CurrentWaypointIndex == PatrolWayPoints.Count-1)
                {
                    if(!RouteFinished)
                    {
                        SetEnemyState(0);
                        CurrentWaypointIndex = 0;
                        RouteFinished = true;
                    }
                }
                 
            }

            if(targetScanner.GetTargetList() != null)
            {
                enemyState = EnemyState.Chasing;
            }
        
        
    }

    bool resetWanderState;
    private void ChaseBehavior()
    {
        if(targetScanner.GetTargetList() != null)
        {
           

            enemyState = EnemyState.Chasing;
            CurrentTarget = Player;
            Agent.SetDestination(CurrentTarget.transform.position);
        }       
        else
        {
            if(!EnemyWasAlert)
            {
                enemyState = EnemyState.Patrolling;    
            }
            else
            {
                if(!resetWanderState)
                {
                    WanderingWhenAlert = false;
                    enemyState = EnemyState.Alert;

                    resetWanderState = true;
                }
                
            }
            
        }

    }

    int waypointcount = 0;
    private void AlertBehavior()
    {
        //runs in update so once the sound object triggers the alert state this takes effect

        if(enemyState == EnemyState.Alert)
        {
            //make sure the highest sound object noticed is not null
            if(HighestSoundObjectNoticed != null)
            {
                //bool check to make sure following code runs only once
                if(!WanderingWhenAlert)
                {
                    
                    //set agent destination to highest sound obj noticed
                    //even if atp it is deleted, it is fine as setdestination() needs only vector coordinates
                    Agent.SetDestination(HighestSoundObjectNoticed.transform.position);
                    
    
                    //send raycasts to check if a spawn point should be formed in case the enemy hits a wall and a spawn point is formed beyond it
                    CheckDirection(transform.forward,waypointcount); // Forward
                    CheckDirection(-transform.forward,waypointcount); // Back
                    CheckDirection(transform.right,waypointcount); // Right
                    CheckDirection(-transform.right,waypointcount); // Left

                    StartCoroutine(AlertWanderBehavior());
                    waypointcount = AlertWayPoints.Count;
                    WanderingWhenAlert = true;
                }
                
            }
            
        }
        
    }

    public void ListenBehavior(GameObject SoundObject, float SoundNoticed)
    {
        //set enemy state to alert and current target to highest sound noticed
        enemyState = EnemyState.Alert;

        HighestSoundObjectNoticed = SoundObject;
        HighestSoundNoticed = SoundNoticed;

        CurrentTarget = HighestSoundObjectNoticed.transform;
    }

    public void SetEnemyState(int i)
    {
        enemyState = (EnemyState)i;
    }

    RaycastHit hit;
    private void CheckDirection(Vector3 direction, int InitialCount)
    {

        if (!Physics.Raycast(transform.position, direction, out hit, WallCheckDistance, WallCheckLayerMask))
        {
            // No hit, instantiate empty GameObject
            Vector3 spawnPosition = transform.position + direction * WallCheckDistance;
            GameObject alertObject = new GameObject("AlertWaypoint");

            alertObject.transform.position = spawnPosition;

            alertObject.AddComponent<EnemyWaypoints>();
            EnemyWaypoints WaypointGizmo = alertObject.GetComponent<EnemyWaypoints>(); 
            WaypointGizmo.WayPointColor = new Color(255,0,222,255);
            WaypointGizmo.GizmoRadius = 1;

            if(AlertWayPoints.Count == InitialCount)
            {
                AlertWayPoints.Add(alertObject.transform);
            }
           
        }
    }

    int i = 0;
    IEnumerator AlertWanderBehavior()
    {
        while (true)  // This ensures continuous checking
        {
            CurrentTarget = AlertWayPoints[i];
            Agent.SetDestination(AlertWayPoints[i].transform.position);

            // Wait until the enemy reaches the current waypoint
            while (Vector3.Distance(transform.position, AlertWayPoints[i].transform.position) > MaxDist)
            {
                yield return null;  // Wait for the next frame before checking again
            }

            // Wait for 1 second after reaching the waypoint
            yield return new WaitForSeconds(2.5f);

            i++;  // Move to the next waypoint
            if (i >= AlertWayPoints.Count)  // Check if the index exceeds the array length
            {
                break;  
            }
        }

        yield return new WaitForSeconds(2.5f);

        CurrentTarget = OldTarget;
        enemyState = EnemyState.Patrolling;

        //reset the check in the chase logic to return to patrol if the player is out of sight and enemy is not alert 
        EnemyWasAlert = false;
        //reset the check to invoke this IEnumerator to make the enemy move around this sound position
        WanderingWhenAlert = false;
        resetWanderState = false;
        //reset the index value for the patrol behavior when alert
        i = 0;

        foreach (var item in AlertWayPoints)
        {
            Destroy(item.gameObject);
        }
        waypointcount = 0;
        AlertWayPoints.Clear();
        yield break;

        
    }

    private void OnDrawGizmos() 
    {
        targetScanner.ShowGizmos();
        Gizmos.DrawWireSphere(transform.position,EnemyHearingRange);
    }
}
