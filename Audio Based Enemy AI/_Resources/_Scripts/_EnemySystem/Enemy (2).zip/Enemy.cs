using UnityEngine;
using UnityEngine.AI;

using System.Collections;
using System.Collections.Generic;

using DC.Scanner;
using Homebrew;
using Unity.VisualScripting;




public enum EnemyState
{
    Patrolling,
    Alert,
    Chasing,
    Fleeing
};
public class Enemy : MonoBehaviour
{
    [Foldout("Enemy Settings",true)]
    public EnemyState enemyState;
    public NavMeshAgent Agent;
    public float MoveSpeed;
    public float MaxDist = 10;
    public float MinDist = 5;
    public GameObject ChaseIndicator;
    public GameObject AlertIndicator;
    public GameObject FleeIndicator;
   
    [Foldout("Scanner Settings",true)]
    public TargetScanner targetScanner;
    public Transform Player;

    [Foldout("Patrol Settings",true)]
    public List<Transform> PatrolWayPoints;
    [Space(5)]
    public int CurrentWaypointIndex;
    public bool RouteFinished;

    [Foldout("Chase & Hear Settings",true)]
    public float ReturnToPatrolDelay = 2.5f;
    public bool EnemyWasAlert;
    public bool WanderingWhenAlert;
    [Space(5)]
    public GameObject HighestSoundObjectNoticed;
    public float HighestSoundNoticed;

    [Foldout("Flee Settings",true)]
    public float fleeDistance;
    public bool HasFledFromPlayer;
    public LayerMask SoundObjects;

    [Foldout("Enemy Animation",true)]
    public Animator Anim;

    [Foldout("Debug Settings",true)]
    public Transform CurrentTarget;
    public Transform OldTarget;
    


    void Start()
    {
        Agent.speed = MoveSpeed;
    }

    void Update()
    {
        ChaseIndicator.SetActive(enemyState == EnemyState.Chasing);
        AlertIndicator.SetActive(enemyState == EnemyState.Alert);
        FleeIndicator.SetActive(enemyState == EnemyState.Fleeing);

        switch (enemyState)
        {
            case EnemyState.Patrolling:
                PatrolBehavior();
                break;

            case EnemyState.Alert:
                AlertBehavior();
                StartCoroutine(AlertWanderBehavior());
                break;

            case EnemyState.Chasing:
                ChasePlayer();
                break;

            case EnemyState.Fleeing:
                FleeFromPlayer();
                StartCoroutine(FleeTimedBehavior());
                break;
        }
    }

   

    private void PatrolBehavior()
    {
            targetScanner.viewAngle = 60;
            CurrentTarget = PatrolWayPoints[CurrentWaypointIndex].transform;
            OldTarget = CurrentTarget;
            Agent.SetDestination(CurrentTarget.transform.position);

            //Vector3,Distance is too trippy to figure out what's going on, I adjusted some values and it works somehow
            //Basically makes sure to go to the next waypoint if in minimum distance to the current target waypoint
            if (Vector3.Distance(transform.position, CurrentTarget.position) >= MinDist)
            {
                SetEnemyState(0);            
            }

            else if(Vector3.Distance(transform.position, CurrentTarget.position) <= MaxDist)
            {
                //Debug.Log(CurrentWaypointIndex);

                if(CurrentWaypointIndex >= 0&&CurrentWaypointIndex != PatrolWayPoints.Count-1)
                {
                    CurrentWaypointIndex += 1;
                    RouteFinished = false;
                }
                else if(CurrentWaypointIndex == PatrolWayPoints.Count-1)
                {
                    if(!RouteFinished)
                    {
                        SetEnemyState(0);
                        CurrentWaypointIndex = 0;
                        RouteFinished = true;
                    }
                }
                 
            }

            CheckForPlayer();
        
    }

    Vector3 SoundPos;
    void FleeFromPlayer()
    {
        if(!HasFledFromPlayer)
        {
            if(HighestSoundObjectNoticed != null)
            {
                SoundPos = HighestSoundObjectNoticed.transform.position;
            } 

            Vector3 fleeDirection = (transform.position - SoundPos).normalized;
            Vector3 fleeTarget = transform.position + fleeDirection * fleeDistance;
            
            NavMeshHit hit;
            if (NavMesh.SamplePosition(fleeTarget, out hit, fleeDistance, NavMesh.AllAreas))
            {
                Agent.SetDestination(hit.position);
                HasFledFromPlayer = true;
            }

            
        }
       
    }

    

    IEnumerator FleeTimedBehavior()
    {
        
        
        Debug.Log("Checking if reached!");
        CheckIfEnemyReachedSpot();

        if(ReachedSpot)
        {
            yield return new WaitForSeconds(ReturnToPatrolDelay);

            enemyState = EnemyState.Patrolling;
            ReachedSpot = false;
            HasFledFromPlayer = false;
            yield break;
        }
        

    }

    bool ReachedSpot = false;
    private void CheckIfEnemyReachedSpot()
    {
        if (!Agent.pathPending) // Check if the path is computed
        {
            if (Agent.remainingDistance <= Agent.stoppingDistance) // Check if the agent is close enough to the end of the path
            {
                if (!Agent.hasPath || Agent.velocity.sqrMagnitude == 0f) // Check if the agent has stopped moving
                {
                    ReachedSpot = true;
                }
            }
        }
    }

    private void CheckForPlayer()
    {
        if(targetScanner.GetTargetList() != null)
        {
           
            enemyState = EnemyState.Chasing;
            //CurrentTarget = Player;
        }       
        else
        {
            if(EnemyWasAlert)
            {
                enemyState = EnemyState.Alert;
                    
            }
            else
            {
                enemyState = EnemyState.Patrolling;
            }
            
        }

    }

    private void ChasePlayer()
    {
        CurrentTarget = Player;
        Agent.SetDestination(CurrentTarget.transform.position);
        CheckForPlayer();
    }


    private void AlertBehavior()
    {
        //runs in update so once the sound object triggers the alert state this takes effect

        if(enemyState == EnemyState.Alert)
        {
            if(HighestSoundNoticed > 0.6f)
            {
                targetScanner.viewAngle = 15f;
            }
            else
            {
                targetScanner.viewAngle = 120;
            }
            
            CheckForPlayer();
            
            //make sure the highest sound object noticed is not null
            if(HighestSoundObjectNoticed != null)
            {
                //bool check to make sure following code runs only once
                
                //set agent destination to highest sound obj noticed
                //even if atp it is deleted, it is fine as setdestination() needs only vector coordinates
                Vector3 SoundPosition = HighestSoundObjectNoticed.transform.position;
                Agent.SetDestination(HighestSoundObjectNoticed.transform.position);
                
                
            }
            
        }
        
    }

    public void ListenBehavior(GameObject SoundObject, float SoundNoticed)
    {
        //set enemy state to alert and current target to highest sound noticed

        HighestSoundObjectNoticed = SoundObject;
        HighestSoundNoticed = SoundNoticed;


        if(HighestSoundNoticed >= 0.2f && HighestSoundNoticed <= 0.6f)
        {
            enemyState = EnemyState.Alert;
            CurrentTarget = HighestSoundObjectNoticed.transform;
        }
       
    }

    IEnumerator AlertWanderBehavior()
    {
        Debug.Log("Checking if reached!");
        CheckIfEnemyReachedSpot();

        if(ReachedSpot)
        {
            yield return new WaitForSeconds(ReturnToPatrolDelay);

            enemyState = EnemyState.Patrolling;
            EnemyWasAlert = false;
            WanderingWhenAlert = false;
            ReachedSpot = false;
            yield break;
        }
        
    }

    public void SetEnemyState(int i)
    {
        enemyState = (EnemyState)i;
    }

    private void OnDrawGizmos() 
    {
        targetScanner.ShowGizmos();
    }
}
